Hello there,

A new product has been submitted to your site (%site_url%).

Summary of the product:
------------------------

Title: %title%
Price: %price%
Seller: %seller_name% (%seller_url%)
Category: %category%

The product is currently in "publish" state. So everyone can view the product.

In case it needs to be moderated:
%product_link%

---
%site_name%
%site_url%