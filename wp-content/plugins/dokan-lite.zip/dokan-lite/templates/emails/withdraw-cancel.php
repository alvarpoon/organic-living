Hi %username%,

Your withdraw request has been cancelled!

You sent a withdraw request of:

Amount: %amount%
Method: %method%

Here's the reason, why:
%notes%

---
%site_name%
%site_url%