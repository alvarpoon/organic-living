Hello %seller_name%,

Your product "%title%" has been approved by one of our admin, congrats!

View product: %product_link%
Update: %product_edit_link%

---
Sent from %site_name%
%site_url%