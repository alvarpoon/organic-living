Hello there,

A new product has been submitted to your site (%site_url%).

Summary of the product:
------------------------

Title: %title%
Price: %price%
Seller: %seller_name% (%seller_url%)
Category: %category%

The product is currently in "pending" state. Please review this product before it goes public.

Moderate: %product_link%

---
%site_name%
%site_url%