<?php
/**
 * Dokan Dahsboard Withdra Header Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>
<header class="dokan-dashboard-header">
    <h1 class="entry-title"><?php _e( 'Withdraw', 'dokan' ); ?></h1>
</header><!-- .entry-header -->
