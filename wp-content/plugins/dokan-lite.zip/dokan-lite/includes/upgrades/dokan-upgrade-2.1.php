<?php

$dokan_installer = new Dokan_Installer();
$dokan_installer->create_announcement_table();

