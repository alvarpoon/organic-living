Instructions:
----------------------------
1. File name structure is: wpuf-LOCALE.po, e.g: wpuf-en_US.po
2. Copy default.po in you language, and open with poEdit
3. Translate